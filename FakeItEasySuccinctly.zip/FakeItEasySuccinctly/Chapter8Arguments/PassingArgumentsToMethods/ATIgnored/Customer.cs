﻿namespace FakeItEasySuccinctly.Chapter8Arguments.PassingArgumentsToMethods.ATIgnored
{
    public class Customer
    {
        public string Email { get; set; }
    }
}

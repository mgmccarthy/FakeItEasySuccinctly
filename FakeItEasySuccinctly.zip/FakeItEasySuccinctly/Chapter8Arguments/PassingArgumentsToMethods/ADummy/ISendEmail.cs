﻿namespace FakeItEasySuccinctly.Chapter8Arguments.PassingArgumentsToMethods.ADummy
{
    public interface ISendEmail
    {
        Result SendEmail(string from, string to);
    }
}

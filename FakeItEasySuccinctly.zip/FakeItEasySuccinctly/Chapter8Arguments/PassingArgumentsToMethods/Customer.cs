﻿namespace FakeItEasySuccinctly.Chapter8Arguments.PassingArgumentsToMethods
{
    public class Customer
    {
        public string Email { get; set; }
    }
}

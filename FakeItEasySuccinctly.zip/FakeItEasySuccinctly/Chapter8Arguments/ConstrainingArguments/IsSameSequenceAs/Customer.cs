﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.IsSameSequenceAs
{
    public class Customer
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
    }
}

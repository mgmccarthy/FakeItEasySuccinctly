﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.DealingWithObject
{
    public interface ISendEmail
    {
        void SendMail(Email mail);
    }
}

﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.DealingWithObject
{
    public class Customer
    {
        public string Email { get; set; }
        public bool IsPreferred { get; set; }
    }
}

﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.DealingWithObject
{
    public class PreferredCustomerEmail
    {
        public string Email { get; set; }
    }
}

﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.DealingWithObject
{
    public class Email
    {
        public object EmailType { get; set; }
    }
}

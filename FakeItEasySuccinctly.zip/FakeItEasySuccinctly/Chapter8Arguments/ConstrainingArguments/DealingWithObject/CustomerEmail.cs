﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.DealingWithObject
{
    public class CustomerEmail
    {
        public string Email { get; set; }
    }
}

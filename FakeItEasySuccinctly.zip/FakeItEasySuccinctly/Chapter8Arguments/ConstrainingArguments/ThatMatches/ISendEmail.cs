﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.ThatMatches
{
    public interface ISendEmail
    {
        void SendMail(Email email);
    }
}

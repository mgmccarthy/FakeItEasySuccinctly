﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.ThatMatches
{
    public class Customer
    {
        public string Email { get; set; }
    }
}

﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.IsInstanceOf
{
    public interface IBus
    {
        void Send(object message);
    }
}

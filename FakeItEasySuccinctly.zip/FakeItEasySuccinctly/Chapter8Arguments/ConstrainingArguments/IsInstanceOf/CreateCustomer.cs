﻿namespace FakeItEasySuccinctly.Chapter8Arguments.ConstrainingArguments.IsInstanceOf
{
    public class CreateCustomer
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}

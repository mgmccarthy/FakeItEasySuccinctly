﻿namespace FakeItEasySuccinctly.Chapter7Assertions.MustHaveHappened.BasicUsage
{
    public interface ISendEmail
    {
        void SendMail();
    }
}

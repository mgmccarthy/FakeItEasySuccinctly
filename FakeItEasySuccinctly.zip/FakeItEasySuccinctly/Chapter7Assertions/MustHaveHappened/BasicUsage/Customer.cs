﻿namespace FakeItEasySuccinctly.Chapter7Assertions.MustHaveHappened.BasicUsage
{
    public class Customer
    {
    }
}

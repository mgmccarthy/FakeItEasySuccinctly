﻿namespace FakeItEasySuccinctly.Chapter7Assertions.MustHaveHappened.Repeated
{
    public interface ISendEmail
    {
        void SendMail();
    }
}

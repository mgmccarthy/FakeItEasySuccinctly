﻿namespace FakeItEasySuccinctly.Chapter7Assertions.MustHaveHappened.Repeated
{
    public class Customer
    {
    }
}

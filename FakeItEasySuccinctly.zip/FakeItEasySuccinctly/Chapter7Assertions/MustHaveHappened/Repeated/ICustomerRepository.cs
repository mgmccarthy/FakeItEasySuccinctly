﻿using System.Collections.Generic;

namespace FakeItEasySuccinctly.Chapter7Assertions.MustHaveHappened.Repeated
{
public interface ICustomerRepository
{
    List<Customer> GetAllCustomers();
}
}

﻿namespace FakeItEasySuccinctly.Chapter7Assertions.MustNotHaveHappened
{
    public interface ISendEmail
    {
        void SendMail();
    }
}

﻿namespace FakeItEasySuccinctly.Chapter7Assertions.MustNotHaveHappened
{
    public class Customer
    {
    }
}

﻿namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.OutAndRefParameters
{
public interface ISendEmail
{
    void SendMail();
}
}
 
﻿namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.OutAndRefParameters
{
    public class Customer
    {
        public string EmailAddress { get; set; }
    }
}

﻿namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.ReturnValues.ReturnsNextFromSequence
{
    public interface ISendEmail
    {
        void SendMail(Email email);
    }
}

﻿using System;

namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.ReturnValues.ReturnsNextFromSequence
{
    public class Email
    {
        public Guid Id { get; set; }
        public string To { get; set; }
    }
}

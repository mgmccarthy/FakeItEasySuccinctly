﻿namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.ReturnValues.ReturnsNextFromSequence
{
    public class Customer
    {
        public string Email { get; set; }
    }
}

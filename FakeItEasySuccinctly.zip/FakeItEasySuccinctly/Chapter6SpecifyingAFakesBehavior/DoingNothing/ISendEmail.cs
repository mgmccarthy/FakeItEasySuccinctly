﻿namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.DoingNothing
{
public interface ISendEmail
{
    void SendMail();
}
}

﻿namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.Invokes
{
    public class Customer
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
    }
}

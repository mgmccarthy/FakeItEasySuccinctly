﻿namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.Strict
{
    public interface IDoSomething
    {
        string DoSomething();
        string DoSomethingElse();
    }
}

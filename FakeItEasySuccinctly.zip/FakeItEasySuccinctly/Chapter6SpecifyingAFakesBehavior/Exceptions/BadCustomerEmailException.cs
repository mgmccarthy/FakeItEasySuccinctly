﻿using System;

namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.Exceptions
{
    public class BadCustomerEmailException : Exception
    {
    }
}

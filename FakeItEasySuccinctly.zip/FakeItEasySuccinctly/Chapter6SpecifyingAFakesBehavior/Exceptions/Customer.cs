﻿namespace FakeItEasySuccinctly.Chapter6SpecifyingAFakesBehavior.Exceptions
{
public class Customer
{
    public string EmailAddress { get; set; }
}
}

﻿namespace FakeItEasySuccinctly.Chapter2UnitTestingIocAndStubs.FakeItEasy
{
    public class Customer
    {
        public int Id { get; set; }
    }
}

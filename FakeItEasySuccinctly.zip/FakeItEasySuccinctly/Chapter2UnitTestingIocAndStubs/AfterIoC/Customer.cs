﻿namespace FakeItEasySuccinctly.Chapter2UnitTestingIocAndStubs.AfterIoC
{
    public class Customer
    {
        public int Id { get; set; }
    }
}

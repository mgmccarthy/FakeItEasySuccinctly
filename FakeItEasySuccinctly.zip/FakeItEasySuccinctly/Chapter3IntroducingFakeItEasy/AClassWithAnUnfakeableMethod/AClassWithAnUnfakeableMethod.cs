﻿namespace FakeItEasySuccinctly.Chapter3IntroducingFakeItEasy.AClassWithAnUnfakeableMethod
{
    public class AClassWithAnUnfakeableMethod
    {
        public void YouCantFakeMe()
        {
            //some implementation
        }
    }
}
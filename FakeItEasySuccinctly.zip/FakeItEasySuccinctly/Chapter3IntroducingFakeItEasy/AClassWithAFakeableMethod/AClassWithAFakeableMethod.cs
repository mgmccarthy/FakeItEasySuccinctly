﻿namespace FakeItEasySuccinctly.Chapter3IntroducingFakeItEasy.AClassWithAFakeableMethod
{
    public class AClassWithAFakeableMethod
    {
        public virtual void YouCanFakeMe()
        {
            //some implementation
        }
    }
}

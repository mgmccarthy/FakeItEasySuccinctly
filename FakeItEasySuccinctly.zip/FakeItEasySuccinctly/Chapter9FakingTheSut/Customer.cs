﻿namespace FakeItEasySuccinctly.Chapter9FakingTheSut
{
    public class Customer
    {
        public string Email { get; set; }
    }
}

﻿namespace FakeItEasySuccinctlyMVC.Models
{
    public class BuildUrl
    {
        public string Url { get; set; }
    }
}